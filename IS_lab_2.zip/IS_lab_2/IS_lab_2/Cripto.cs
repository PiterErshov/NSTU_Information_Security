﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Security.Cryptography;
using System.Collections;
using MathNet.Numerics;

namespace IS_lab_2
{
    class Cripto
    {
        const double F_S = 1.82138636; // значение статистики для частотного теста
        double[] Stat = new double[16] { 3.841, 5.991, 7.815, 9.488, 11.070, 12.592, 14.067, 15.507,
                                        16.919, 18.307, 19.675, 21.026, 22.362, 23.685, 24.996, 26.296 };
        public void Write(string fileName, string[] outw)  // Запись входной строки и ключа в файл
        {
            using (StreamWriter sw = new StreamWriter(fileName))
            {
                foreach (string str in outw)
                    sw.WriteLine(str);
            }
        }
        public byte[] TriDES(byte[] Data, byte[] Key, byte[] IV) // 3DES алгоритм
        {
            MemoryStream mStream = new MemoryStream();  // создаём поток памяти

            TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider(); // объект класса 3DES
            tdes.Padding = PaddingMode.None; //отключаем дополнение выходного шифротекства справа
            tdes.Mode = CipherMode.CFB; // включаепм режим CFB, чтобы установить длину шифротекста в 64 бита

            CryptoStream cStream = new CryptoStream(mStream,
                tdes.CreateEncryptor(Key, IV),
                CryptoStreamMode.Write); // создаём поток для шифрования
           
            byte[] toEncrypt = Data;

            cStream.Write(toEncrypt, 0, toEncrypt.Length); // помещаем данные в поток шифрования
            cStream.FlushFinalBlock();

            byte[] ret = mStream.ToArray(); // извлекаем шифротекст

            cStream.Close(); // закрываем потоки
            mStream.Close();

            return ret;
        }

        public byte[] key_gen() // генератор 128-битного ключа
        {
            byte[] key = new byte[128]; // основной ключ
            byte[] b1 = new byte[64]; // 64-битная часть ключа
            byte[] b2 = new byte[64]; // 64-битная часть ключа
            byte[] xor = new byte[64]; // 64-битная блок случайных бит для равномерного преобразования ключа
            byte[] bit = new byte[1]; // случайный бит для выбора совмещения двух частей ключа (1 - !b1 + b2, 0 - b2 + !b1)
            var rand = new Random(); // структура для рандома

            rand.NextBytes(b1); // создаём случайную половину ключа
            rand.NextBytes(b2); // создаём случайную половину ключа
            rand.NextBytes(xor); // создаём случайную последовательность для оперции xor с половинами ключа
            ulong k1 = BitConverter.ToUInt64(b1, 0); // переводим в ulong формат
            ulong k2 = BitConverter.ToUInt64(b2, 0); // переводим в ulong формат

            ulong xr = BitConverter.ToUInt64(xor, 0); // переводим в ulong формат
            k1 ^= xr; // приводим к равномерному виду
            xr = BitConverter.ToUInt64(xor, 0); 
            k2 ^= xr; // приводим к равномерному виду

            rand.NextBytes(bit); // создаём случайное число (0 или 1), чтобы выбрать, какую половину ключа поставить первой и какую инвертировать
            if (bit[0] == 1)
            {
                b1 = BitConverter.GetBytes(~k1); // обрачаем число
                b2 = BitConverter.GetBytes(k2);
                key = b1.Concat(b2).ToArray(); // соединяем половины 128-битного ключа
            }
            else
            {
                b1 = BitConverter.GetBytes(k1);
                b2 = BitConverter.GetBytes(~k2); // обрачаем число
                key = b2.Concat(b1).ToArray(); // соединяем половины 128-битного ключа
            }

            return key;
        }

        public ulong[] ANSI(int m) // алгоритм ANSI X9.17
        {
            ulong[] X = new ulong[m]; // результирующая последовательность из m 64-битных чисел
            DateTime date1 = DateTime.Now; // структура для извлечения даты и времени
            var rand = new Random(); // структура для получения рандомных чисел

            byte[] s_0 = new byte[64]; // начальное случайное секретное 64-битное число
            rand.NextBytes(s_0); // 

            for (int i = 0; i < m; i++) // основной цикл
            {
                byte[] d = BitConverter.GetBytes((ulong)date1.ToBinary()); // получаем дату и время в 64-битном формате
                byte[] IV = new byte[128]; // 128-битный вектор инициализации для шифрования чисел 3DES
                rand.NextBytes(IV); // получаем случайный вектор (использование случайного вектора позволяет избежать дублирующихся блоков в шифротексте)
                byte[] buf = TriDES(d, key_gen(), IV); // зашифрованные дата и время
                ulong b1 = BitConverter.ToUInt64(buf, 0); // преобразуем зашифрованную дату и время в ulong для битовых операций
                ulong s = BitConverter.ToUInt64(s_0, 0); //  преобразуем секретное число в ulong для битовых операций
                s ^= b1; // проводим xor операцию с секретным числом и зашифрованными датой, временем
                buf = BitConverter.GetBytes(s); // переводим результат xor обратно в массив байтов для повторного шифрования
                rand.NextBytes(IV); // получаем новый случайный вектор инициализации
                buf = TriDES(buf, key_gen(), IV); // шифруем результат xor
                X[i] = BitConverter.ToUInt64(buf, 0); // получаем одно из результирующих псевдослучайных чисел
                b1 ^= X[i]; // проводим операцию xor с результирующим числом и предыдущим xor
                buf = BitConverter.GetBytes(b1); // переводим xor в массив байтов
                rand.NextBytes(IV); // шифруем результат второго xor чтобы получить новое начальное случайное число для следующей итерации цикла
            }
            return X;
        }

        public int[] zero_invert(int[] X) // функция замены нулей на -1
        {
            int[] bin_seq = new int[X.Length]; 

            for (int i = 0; i < bin_seq.Length; i++)
            {
                bin_seq[i] = X[i];
                if (bin_seq[i] == 0) 
                    bin_seq[i] = -1;
            }

            return bin_seq;
        }

        public int[] num_convert(ulong[] X) // перевод массива чисел ulong в int массив 0 и 1
        {
            int[] bin_seq = new int[X.Length * 64]; // результирующий массив длиной в 64*число элементов во входном массиве
            int k = 0;
            for(int i = 0; i < X.Length; i++)
            {
                BitArray buf = new BitArray(BitConverter.GetBytes(X[i])); // превод элемента массива ulong в масив байтов, а затем в массив битов
                for (int j = 0; j < buf.Length; j++)
                {
                    if (buf[j])
                        bin_seq[k] = 1;
                    else
                        bin_seq[k] = 0;
                    k++;
                }
            }
            return bin_seq;
        }

        public double[] freq_test(int[] Seq) // частотный тест
        {
            int S = 0; // сумма всех элементов последовательности
            double[] res = new double[3]; // результирующий массив (нужет для регистрации всех шагов теста)

            for (int i = 0; i < Seq.Length; i++) // получаем сумму элементов последовательности
                S += Seq[i];

            double Stat = Math.Abs(S) / Math.Sqrt(Seq.Length); // находим статистику
            res[0] = S; // сохраняем сумму
            res[1] = Stat; // сохраняем статистику
            if (Stat <= F_S) // если статистика меньше или равна тестовой - тест пройден
                res[2] = 1;
            else
                res[2] = 0;

            return res;
        }

        public double[] same_bits_test(int[] Seq) // тест на последовательность одинаковых бит
        {
            double pi = 0; // частота появленяи единиц в последовательности
            int V = 1; // количество ситуаций, при которых соседние числа последовательности не равны друг другу 
            double[] res = new double[4]; // результирующий массив (нужет для регистрации всех шагов теста)

            for (int i = 0; i < Seq.Length; i++) // находим частоту встречи единиц в последовательности
                pi += Seq[i];
            pi /= Seq.Length;

            for (int i = 0; i < Seq.Length - 1; i++) // находим все ситуации, когда соседние элементы не равны друг другу
                if (Seq[i] != Seq[i + 1]) 
                    V += 1;

            double Stat = Math.Abs(V - 2 * pi * Seq.Length * (1 - pi)) /
                          (2 * pi * (1 - pi) * Math.Sqrt(2 * Seq.Length)); // статистика
            res[0] = pi; 
            res[1] = V;
            res[2] = Stat;

            if (Stat <= F_S)
                res[3] = 1;
            else
                res[3] = 0;

            return res;
        }

        public int[] state_check(int[] S, int[] eps) // подсчёт количества встреч чисел от -9 до 9 (кроме 0) в последовательности
        {
            for (int i = -9; i < 0; i++)
                for (int j = 0; j < S.Length; j++)
                    if (S[j] == i)
                        eps[i + 9]++;

            for (int i = 1; i < 10; i++)
                for (int j = 0; j < S.Length; j++)
                    if (S[j] == i)
                        eps[i + 8]++;
            return eps;
        }

        public bool Y_check(double[] Y) // получение статистик для ситуаций, полученных в state_check
        {
            for (int i = 0; i < Y.Length; i++)
                if (Y[i] > F_S)
                    return false;
            return true;
        }

        public double[] rand_dev_test(int[] Seq) // расширенный тест на произвольные отклонения
        {            
            int[] S = new int[Seq.Length + 2]; // новая последовательность возростающих сумм (содержит 0 в начальном и последнем элементах)
            int[] eps = new int[18]; // количество встреч чисел от -9 до 9 (кроме 0) в S
            double[] Y = new double[18]; // статистики для eps             
            int k = 0; // число нулей в S 
            int L = 0; // число нулей - 1 в S

            for (int i = 1; i < Seq.Length + 1; i++) // получаем возростающие суммы
                S[i] += S[i - 1] + Seq[i - 1];

            for (int i = 0; i < S.Length; i++) // получаем число нулей
                if (S[i] == 0)
                    k++;
            
            L = k - 1;

            eps = state_check(S, eps); // получаем число встреч чисел

            for (int i = -9; i < 0; i++) // получаем статистики для чисел от -9 до -1
                Y[i + 9] = Math.Abs(eps[i + 9] - L) / Math.Sqrt(2 * L * (4 * Math.Abs(i) - 2));

            for (int i = 1; i < 10; i++) // получаем статистики для чисел от 1 до 9
                Y[i + 8] = Math.Abs(eps[i + 8] - L) / Math.Sqrt(2 * L * (4 * Math.Abs(i) - 2));

            double[] res = new double[S.Length + 2 * eps.Length + 2]; // результирующий массив (нужет для регистрации всех шагов теста)

            for (int i = 0; i < S.Length; i++) // сохраняем возростающие суммы
                res[i] = S[i];

            for (int i = 0; i < eps.Length; i++) // сохраняем число встреч
                res[i + S.Length] = eps[i];

            for (int i = 0; i < eps.Length; i++)
                res[i + S.Length + eps.Length] = Y[i];

            res[S.Length + 2 * eps.Length] = L;

            if (Y_check(Y))
                res[S.Length + 2 * eps.Length + 1] = 1;
            else
                res[S.Length + 2 * eps.Length + 1] = 0;

            return res;
        }

        public double Rav(double X, double a, double b)
        {
            return (X - a) / (b - a);
        }

        public double crit(double S, int r) // вычисление статистики
        {
            double coef = 1 / (Math.Pow(2, (r / 2)) * SpecialFunctions.Gamma(r / 2));
            double f = MathNet.Numerics.Integration.NewtonCotesTrapeziumRule.IntegrateAdaptive( x => Math.Pow(x, (r / 2) - 1) * Math.Pow(Math.E, -x / 2), S, 10000000, 1e-5);
            return coef * f;
        }
        public double[] hi_2(int[] Seq) // Критерий согласия хи-квадрат Пирсона
        {
            double[] res = new double[3];
            int Max = 1;
            int Min = -1;

            double K = 5 * Math.Log10(Seq.Length);
            double[] P = new double[1];
            double[] v = new double[(int)K];
            double[] inter = new double[(int)K + 1];
            double u = Min;
            for (int i = 0; i < (int)K + 1; i++)
            {
                inter[i] = u;
                u += ((Max - Min) / K);
            }

            for(int i = 0; i < Seq.Length; i++)
                for(int j = 0; j < inter.Length - 1; j++)
                {
                    if (Seq[i] >= inter[j] && Seq[i] <= inter[j + 1])
                        v[j]++;
                }

            for (int i = 0; i < v.Length; i++)
                v[i] /= Seq.Length;

            for(int i = 1; i < inter.Length; i++)
            {
                P[i - 1] = Rav(inter[i], 0, 1) - Rav(inter[i - 1], 0, 1);
                Array.Resize(ref P, P.Length + 1);
            }
            Array.Resize(ref P, P.Length - 1);
            double summ = 0;
            for (int i = 0; i < (int)K; i++)
                summ += Math.Pow(v[i] - P[i], 2) / P[i];

            summ *= Seq.Length;
            res[0] = summ;

            double S_t = crit(summ, (int)K - 2);
            res[1] = S_t;
            if (S_t <= summ)
                res[2] = 1;
            else
                res[2] = 0;
            return res;
        }

        public int Peroid(int[] seq) //Вычисление периода
        {
            int per = 1;
            int step = 0;
            while (step + per != seq.Length)
            {
                if (seq[step] != seq[per + step])
                {
                    ++per;
                    step = 0;
                }
                else
                {
                    ++step;
                }
            }
            return per;
        }
    }
}
