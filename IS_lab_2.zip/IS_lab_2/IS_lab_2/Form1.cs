﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Collections;

namespace IS_lab_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string mess = textBox1.Text; // получаем количество 64-битных чисел
            if (mess == "" || Convert.ToInt32(mess) == 0) // проверка на корректное количество чисел
                MessageBox.Show("Введите количество чисел больше 0.");
            else
            {
                Cripto Cr = new Cripto(); // создаём основной класс
                // очищаем все textBox при нажании на кнопку
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();

                ulong[] ansi = Cr.ANSI(Convert.ToInt32(mess)); // массив псевдослучайных чисел
                int[] Seq = Cr.num_convert(ansi); // подготовка последовательности преобразуем все числа
                                                  //в массив int значений(1, 0)
                string[] out_seq = new string[1]; // выходной массив для записи строки двоичных чисел в файл

                for (int i = 0; i < Seq.Length; i++) // получение строки двоичных чисел
                    out_seq[0] += Seq[i].ToString();
                string binary = "";
                for (int i = 0; i < ansi.Length; i++) // вывод чисел в hex и в двоичном формате
                {
                    textBox2.Text += ansi[i].ToString("x") + " ";
                    binary += Convert.ToString((long)ansi[i], toBase: 2);

                }
                textBox3.Text = binary;
                Cr.Write("out.txt", out_seq); // запись в файл выходной двоичной последовательности
                int[] Seq_m = Cr.zero_invert(Seq); // получение массива значений -1 и 1
                textBox14.Text = Cr.Peroid(Seq).ToString();
                double[] Freq_res = Cr.freq_test(Seq_m); // частотный тест
                // вывод шагов теста
                textBox4.Text += "Сумма элементов " + Freq_res[0].ToString() + Environment.NewLine;
                textBox4.Text += "Статистика " + Freq_res[1].ToString() + Environment.NewLine;
                // если частотный тест не пройден, то нет смысла в других тестах
                if (Freq_res[2] == 1)
                {
                    textBox7.Text = "Пройден ";

                    double[] same_res = Cr.same_bits_test(Seq); // тест на последовательность одинаковых бит
                    // вывод шагов теста
                    textBox5.Text += "Частота появления единиц " + same_res[0].ToString() + Environment.NewLine;
                    textBox5.Text += "Vn " + same_res[1].ToString() + Environment.NewLine;
                    textBox5.Text += "Статистика " + same_res[2].ToString() + Environment.NewLine;
                    // проверка прохождения теста
                    if (same_res[3] == 1)
                        textBox8.Text = "Пройден";
                    else
                        textBox8.Text = "Не пройден";

                    double[] rand_res = Cr.rand_dev_test(Seq_m); // расширенный тест на произвольные отклонения

                    // вывод шагов теста
                    string rt = "";

                    for (int i = 0; i < rand_res.Length - 2 - 2 * 18; i++)
                        rt += rand_res[i].ToString() + Environment.NewLine;
                    textBox6.Text = rt;

                    rt = "";
                    for (int i = rand_res.Length - 2 - 2 * 18; i < rand_res.Length - 2 - 18; i++)
                        rt += rand_res[i].ToString() + Environment.NewLine;
                    textBox10.Text = rt;

                    rt = "";
                    for (int i = rand_res.Length - 2 - 18; i < rand_res.Length - 2; i++)
                        rt += rand_res[i].ToString() + Environment.NewLine;
                    textBox11.Text = rt;

                    textBox12.Text = rand_res[rand_res.Length - 2].ToString();
                    // проверка прохождения теста
                    if (rand_res[rand_res.Length - 1] == 1)
                        textBox9.Text = "Пройден";
                    else
                        textBox9.Text = "Не пройден";

                    double[] hi_2 = Cr.hi_2(Seq_m);
                    if (hi_2[2] == 1)
                        textBox13.Text = "Пройден";
                    else
                        textBox13.Text = "Не пройден";
                }
                else
                {
                    textBox7.Text = "Не пройден ";
                    MessageBox.Show("Дальнейшие тесты не требуются, последовательность не случайная.");
                }
            }
        }
    }
}
