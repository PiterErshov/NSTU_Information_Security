﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace IS_lab3
{
    public partial class Sym : Form
    {
        public Sym()
        {
            InitializeComponent();
            comboBox1.Items.Add("3DES");
            comboBox1.Items.Add("AES");
            comboBox1.SelectedIndex = 0;
        }

        byte[] b_mess = new byte[1]; // сообщение в байтах
        string[] mess = new string[1]; // сообщение в строках
        string alg_flag = ""; // название алгоритма
        byte[] encypt = new byte[1]; // шифротекст
        byte[] decypt = new byte[1]; // дешифрованное сообщение
        byte[] KEY = new byte[1]; // ключ
        byte[] IV = new byte[1]; // вектор инициализации
        private void Button3_Click(object sender, EventArgs e)
        {
            File_f F = new File_f();
            string file_name = textBox1.Text;
            if (file_name == "") // проверка на ввод имени файла
                MessageBox.Show("Enter file name.");
            else
            {
                bool fl = File.Exists(file_name); // проверка на существование файла
                if (fl)
                {
                    b_mess = File.ReadAllBytes(file_name);
                    mess = F.Read(file_name);
                    string ms = "";
                    for (int i = 0; i < mess.Length; i++)
                        ms += mess[i];
                    textBox2.Text = ms;
                }
                else
                    MessageBox.Show("File don't exist.");
            }
        }

        private void Button1_Click(object sender, EventArgs e) // шифруем сообщения
        {
            textBox3.Clear();

            string file_name = "";
            alg_flag = comboBox1.SelectedItem.ToString();
            Sym_alg SM = new Sym_alg();
            
            KEY = File.ReadAllBytes("key.bin");
            IV = File.ReadAllBytes("iv.bin");

            if (alg_flag == "3DES")
            {
                encypt = SM.TriDES_Encrypt(b_mess, KEY, IV);
                file_name = "enc_3DES.bin";
            }
            if (alg_flag == "AES")
            {
                encypt = SM.AES_Encrypt(b_mess, KEY, IV);
                file_name = "enc_AES.bin";
            }

            File.WriteAllBytes(file_name, encypt);

            for (int i = 0; i < encypt.Length; i++)
                textBox3.Text += encypt[i].ToString("x") + " ";
                        
        }

        private void Button2_Click(object sender, EventArgs e) // дешируем сообщения
        {
            textBox4.Clear();

            Sym_alg SM = new Sym_alg();
            string file_name = "";
            if (alg_flag == "3DES")
            {
                decypt = SM.TriDES_Decrypt(encypt, KEY, IV);
                file_name = "dec_3DES.txt";
            }
            if (alg_flag == "AES")
            {
                decypt = SM.AES_Decrypt(encypt, KEY, IV);
                file_name = "dec_AES.txt";
            }

            string dec_res = Encoding.UTF8.GetString(decypt, 0, decypt.Length);
            File.WriteAllText(file_name, dec_res);
            textBox4.Text = dec_res;
        }

        private void Button4_Click(object sender, EventArgs e) // генератор ключей
        {
            string file_key = "key.bin";
            string file_IV = "IV.bin";
            textBox5.Clear();
            textBox6.Clear();

            Sym_alg SM = new Sym_alg();

            byte[] k = SM.key_gen();
            byte[] iv = SM.key_gen();

            for (int i = 0; i < k.Length; i++)
                textBox5.Text += k[i].ToString("x") + " ";

            for (int i = 0; i < iv.Length; i++)
                textBox6.Text += iv[i].ToString("x") + " ";

            File.WriteAllBytes(file_key, k);
            File.WriteAllBytes(file_IV, iv);
        }
    }
}
