﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace IS_lab3
{
    class File_f
    {
        public void Write(string fileName, string[] outw)  // Запись входной строки и ключа в файл
        {
            using (StreamWriter sw = new StreamWriter(fileName))
            {
                foreach (string str in outw)
                    sw.WriteLine(str);
            }
        }
        public string[] Read(string fileName)  // чтение строки
        {
            List<string> list = new List<string>();
            using (StreamReader reader = new StreamReader(fileName, Encoding.GetEncoding(1251)))
            {
                while (!reader.EndOfStream)
                {
                    string str = reader.ReadLine();
                    list.Add(str);
                }
            }
            return list.ToArray();
        }
    }
}
