﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography;

namespace IS_lab3
{
    public partial class Dig_key : Form
    {
        public Dig_key()
        {
            InitializeComponent();
            comboBox1.Items.Add("DSA");
            comboBox1.Items.Add("ECDSA");
            comboBox1.Items.Add("HMACSHA512");
            comboBox1.SelectedIndex = 0;
        }


        byte[] b_mess = new byte[1]; // байты сообщения
        string[] mess = new string[1]; // строка с сообщением
        string alg_flag = ""; // название алгоритма
        string para_file_name = "_Paramet.txt"; // левая часть названия файла с параметрами (правой является название алгоритма)
        string out_file_name = "_out.txt"; // левая часть названия файла с подписью (правой является название алгоритма)
        byte[] sig = new byte[1]; // подпись
        private void button1_Click(object sender, EventArgs e)
        {
            File_f F = new File_f();
            textBox2.Clear();
            string file_name = textBox1.Text;
            if (file_name == "") // проверка на ввод имени файла
                MessageBox.Show("Enter file name.");
            else
            {
                bool fl = File.Exists(file_name); // проверка на существование файла
                if (fl)
                {
                    b_mess = File.ReadAllBytes(file_name);
                    mess = F.Read(file_name);
                    string ms = "";
                    for (int i = 0; i < mess.Length; i++)
                        ms += mess[i];
                    textBox2.Text = ms;
                }
                else
                    MessageBox.Show("File don't exist.");
            }          
        }
        private void Button3_Click(object sender, EventArgs e) // создание подписи
        {
            textBox3.Clear();
            Dig_key_alg DKA = new Dig_key_alg();

            alg_flag = comboBox1.SelectedItem.ToString();
            if (alg_flag == "DSA")
            {
                sig = DKA.DSA_Sig_Create(b_mess, alg_flag + para_file_name);
                
                for (int i = 0; i < sig.Length; i++)
                    textBox3.Text += sig[i].ToString("x") + " ";
                textBox6.Text = (sig.Length * 8).ToString();
            }
            if (alg_flag == "ECDSA")
            {
                sig = DKA.ECDSA_Sig_Create(b_mess, alg_flag + para_file_name);

                for (int i = 0; i < sig.Length; i++)
                    textBox3.Text += sig[i].ToString("x") + " ";
                textBox6.Text = (sig.Length * 8).ToString();
            }
            if (alg_flag == "HMACSHA512")
            {
                sig = DKA.HMAC_Sig_Create(b_mess, alg_flag + para_file_name);

                for (int i = 0; i < sig.Length; i++)
                    textBox3.Text += sig[i].ToString("x") + " ";
                textBox6.Text = (sig.Length * 8).ToString();
            }
            File.WriteAllBytes(alg_flag + out_file_name, sig);
        }

        private void button4_Click(object sender, EventArgs e) // модификация подписи
        {
            Dig_key_alg DKA = new Dig_key_alg();
            string b_num = textBox5.Text;
            if (b_num == "" || Convert.ToInt32(b_num) > (sig.Length * 8))
                MessageBox.Show("Не корректный номер бита.");
            else
                sig = DKA.bit_mod(b_num, sig);
        }

        private void button2_Click(object sender, EventArgs e) // проверка подписи
        {
            Dig_key_alg DKA = new Dig_key_alg();
            alg_flag = comboBox1.SelectedItem.ToString();
            if (alg_flag == "DSA")
            {
                if (DKA.DSA_Sig_Ver(b_mess, sig, alg_flag + para_file_name))
                    textBox4.Text = "Верный";
                else
                    textBox4.Text = "Не верный";
            }
            if (alg_flag == "ECDSA")
            {
                if (DKA.ECDSA_Sig_Ver(b_mess, sig, alg_flag + para_file_name))
                    textBox4.Text = "Верный";
                else
                    textBox4.Text = "Не верный";
            }
            if (alg_flag == "HMACSHA512")
            {
                if (DKA.HMAC_Sig_Ver(b_mess, sig, alg_flag + para_file_name))
                    textBox4.Text = "Верный";
                else
                    textBox4.Text = "Не верный";
            }
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            Dig_key_alg DKA = new Dig_key_alg();
            alg_flag = comboBox1.SelectedItem.ToString();
            DKA.Key_gen(alg_flag, alg_flag + para_file_name); // создаём ключ
        }
    }
}
