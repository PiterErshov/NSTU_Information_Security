﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IS_lab3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // вызов окон
        private void button2_Click(object sender, EventArgs e) // асимметричный алгоритм
        {
            Asym examp = new Asym();
            examp.Show();
        }

        private void Button1_Click(object sender, EventArgs e) // симметричные алгоритмы
        {
            Sym examp = new Sym();
            examp.Show();
        }

        private void Button3_Click(object sender, EventArgs e) // цифровые ключи
        {
            Dig_key examp = new Dig_key();
            examp.Show();
        }

        private void Button4_Click(object sender, EventArgs e) // хэш-функции
        {
            Hash examp = new Hash();
            examp.Show();
        }
    }
}
