﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Security.Cryptography;
using System.Collections;
using System.Threading;

namespace IS_lab3
{
    class Sym_alg
    {
        public byte[] key_gen() // генератор 128-битного ключа
        {
            byte[] key = new byte[128]; // основной ключ
            byte[] b1 = new byte[64]; // 64-битная часть ключа
            byte[] b2 = new byte[64]; // 64-битная часть ключа
            byte[] xor = new byte[64]; // 64-битная блок случайных бит для равномерного преобразования ключа
            byte[] bit = new byte[1]; // случайный бит для выбора совмещения двух частей ключа (1 - !b1 + b2, 0 - b2 + !b1)
            
            Thread.Sleep(20); // тормозим генерацию ключа, чтобы новый ключ был случайным
            var rand = new Random((int)DateTime.Now.Ticks & 0x0000FFFF);
            rand.NextBytes(b1); // создаём случайную половину ключа
            rand.NextBytes(b2); // создаём случайную половину ключа

            rand.NextBytes(xor); // создаём случайную последовательность для оперции xor с половинами ключа
            ulong k1 = BitConverter.ToUInt64(b1, 0); // переводим в ulong формат
            ulong k2 = BitConverter.ToUInt64(b2, 0); // переводим в ulong формат

            ulong xr = BitConverter.ToUInt64(xor, 0); // переводим в ulong формат
            k1 ^= xr; // приводим к равномерному виду
            xr = BitConverter.ToUInt64(xor, 0);
            k2 ^= xr; // приводим к равномерному виду

            rand.NextBytes(bit); // создаём случайное число (0 или 1), чтобы выбрать, какую половину ключа поставить первой и какую инвертировать
            if (bit[0] == 1)
            {
                b1 = BitConverter.GetBytes(~k1); // обрачаем число
                b2 = BitConverter.GetBytes(k2);
                key = b1.Concat(b2).ToArray(); // соединяем половины 128-битного ключа
            }
            else
            {
                b1 = BitConverter.GetBytes(k1);
                b2 = BitConverter.GetBytes(~k2); // обрачаем число
                key = b2.Concat(b1).ToArray(); // соединяем половины 128-битного ключа
            }

            return key;
        }
        public byte[] TriDES_Encrypt(byte[] Data, byte[] Key, byte[] IV) // 3DES шифратор
        {
            MemoryStream mStream = new MemoryStream();  // создаём поток памяти

            TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider(); // объект класса 3DES
            //tdes.Padding = PaddingMode.None; //отключаем дополнение выходного шифротекства справа
            tdes.Mode = CipherMode.CFB; // включаепм режим CFB, чтобы установить длину шифротекста в 64 бита

            CryptoStream cStream = new CryptoStream(mStream,
                tdes.CreateEncryptor(Key, IV),
                CryptoStreamMode.Write); // создаём поток для шифрования

            byte[] toEncrypt = Data;

            cStream.Write(toEncrypt, 0, toEncrypt.Length); // помещаем данные в поток шифрования
            cStream.FlushFinalBlock();

            byte[] ret = mStream.ToArray(); // извлекаем шифротекст

            cStream.Close(); // закрываем потоки
            mStream.Close();

            return ret;
        }

        public byte[] TriDES_Decrypt(byte[] Data, byte[] Key, byte[] IV) // 3DES дешифратор
        {
            MemoryStream mStream = new MemoryStream();  // создаём поток памяти

            TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider(); // объект класса 3DES
            //tdes.Padding = PaddingMode.None; //отключаем дополнение выходного шифротекства справа
            tdes.Mode = CipherMode.CFB; // включаепм режим CFB, чтобы установить длину шифротекста в 64 бита

            CryptoStream cStream = new CryptoStream(mStream,
                tdes.CreateDecryptor(Key, IV),
                CryptoStreamMode.Write); // создаём поток для дешифрования

            byte[] toEncrypt = Data;

            cStream.Write(toEncrypt, 0, toEncrypt.Length); // помещаем данные в поток шифрования
            cStream.FlushFinalBlock();

            byte[] ret = mStream.ToArray(); // извлекаем текст

            cStream.Close(); // закрываем потоки
            mStream.Close();

            return ret;
        }


        public byte[] AES_Encrypt(byte[] Data, byte[] Key, byte[] IV) // AES шифратор
        {
            MemoryStream mStream = new MemoryStream();  // создаём поток памяти

            Aes AES = Aes.Create(); // объект класса AES
            AES.Mode = CipherMode.CFB; // включаепм режим CFB, чтобы установить длину шифротекста в 64 бита

            CryptoStream cStream = new CryptoStream(mStream,
                AES.CreateEncryptor(Key, IV),
                CryptoStreamMode.Write); // создаём поток для шифрования

            byte[] toEncrypt = Data;

            cStream.Write(toEncrypt, 0, toEncrypt.Length); // помещаем данные в поток шифрования
            cStream.FlushFinalBlock();

            byte[] ret = mStream.ToArray(); // извлекаем шифротекст

            cStream.Close(); // закрываем потоки
            mStream.Close();

            return ret;
        }

        public byte[] AES_Decrypt(byte[] Data, byte[] Key, byte[] IV) // AES дешифратор
        {
            MemoryStream mStream = new MemoryStream();  // создаём поток памяти

            Aes AES = Aes.Create(); // объект класса 3DES            
            AES.Mode = CipherMode.CFB; // включаепм режим CFB, чтобы установить длину шифротекста в 64 бита

            CryptoStream cStream = new CryptoStream(mStream,
                AES.CreateDecryptor(Key, IV),
                CryptoStreamMode.Write); // создаём поток для дешифрования

            byte[] toEncrypt = Data;

            cStream.Write(toEncrypt, 0, toEncrypt.Length); // помещаем данные в поток дешифрования
            cStream.FlushFinalBlock();

            byte[] ret = mStream.ToArray(); // извлекаем текст

            cStream.Close(); // закрываем потоки
            mStream.Close();

            return ret;
        }
    }
}
