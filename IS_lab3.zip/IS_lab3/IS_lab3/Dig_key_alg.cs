﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Security.Cryptography;
using System.Collections;

namespace IS_lab3
{
    class Dig_key_alg // демонстрационный класс для создания цифровых подписей
    {
        public void Key_gen(string Alg_name, string key_file) // функция генерации ключей (ТОЛЬКО ДЛЯ DSA И HMACSHA512)
        {
            if(Alg_name == "DSA")
            {
                DSACng DS = new DSACng(); // создаём объект класса DSACng
                string param = DS.ToXmlString(true); // экспортируем открытый и закрытый ключи в строку XML формата
                using (StreamWriter writer = new StreamWriter(File.Open(key_file, FileMode.Create))) // записываем строку с файл key_file
                    writer.Write(param);
            }
            if (Alg_name == "HMACSHA512")
            {
                byte[] key = new byte[64];
                RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider(); // создаём объект специального класса для создания ключей
                rng.GetBytes(key); // создаём 64 случайных байта ключа
                File.WriteAllBytes(key_file, key); // записываем ключ в файл
            }
        }
        public byte[] DSA_Sig_Create(byte[] Data, string para_f) // функция для создания DSA подписи
        {
            byte[] Sig = new byte[1]; // подпись
            string param = "";
            using (StreamReader reader = new StreamReader(File.Open(para_f, FileMode.Open))) // считываем параметры из файла 
                param = reader.ReadToEnd();

            DSACng DS = new DSACng(); // объект класса DSACng
            DS.FromXmlString(param); // импортируем параметры 

            Sig = DS.CreateSignature(Data); // создаём подпись

            return Sig;
        }

        public bool DSA_Sig_Ver(byte[] Data, byte[] Signature, string para_f) // фукнция для проверки DSA подписи
        {
            string param = "";
            using (StreamReader reader = new StreamReader(File.Open(para_f, FileMode.Open))) // считываем параметры из файла
                param = reader.ReadToEnd();

            DSACng DS = new DSACng();
            DS.FromXmlString(param); // импортируем параметры

            if (DS.VerifySignature(Data, Signature)) // проверяем подпись
                return true;
            else
                return false;
        }

        public byte[] bit_mod(string n_bit, byte[] Sig) // функция модификации подписи (меняет указанный номер бита в подписи)
        {
            int i = Convert.ToInt32(n_bit); // извлекаем номер бита
            BitArray sig_m = new BitArray(Sig); // преобразуем массив байтов в массив битов
            if (sig_m[i] == true) // инвертируем бит
                sig_m[i] = false;
            else
                sig_m[i] = true;

            byte[] ou = new byte[(sig_m.Length - 1) / 8 + 1]; // преобразуем из битов в байты
            sig_m.CopyTo(ou, 0);
            return ou;
        }

        public byte[] ECDSA_Sig_Create(byte[] Data, string para_f) // функция создания ECDSA подписи
        {
            byte[] Sig = new byte[1];
            ECDsaCng ECD = new ECDsaCng(); // создаём объект основного класса
            ECD.HashAlgorithm = CngAlgorithm.Sha256; // указываем алгоритм, на основе которого будем создавать подпись
            File.WriteAllBytes(para_f, ECD.Key.Export(CngKeyBlobFormat.EccPublicBlob)); // экспортируем ключи в файл (необходимо, для правильной проверки подписи)         
            Sig = ECD.SignData(Data); // создаём подпись

            return Sig;
        }

        public bool ECDSA_Sig_Ver(byte[] Data, byte[] Signature, string para_f) // функция проверки ECDSA подписи
        {
            byte[] key = File.ReadAllBytes(para_f); // получаем ключ из файла
            ECDsaCng ecsdKey = new ECDsaCng(CngKey.Import(key, CngKeyBlobFormat.EccPublicBlob)); // создаём объект с заданным ключом 

            if (ecsdKey.VerifyData(Data, Signature)) // проверяем подпись
                return true;
            else
                return false;
        }
                    
        public byte[] HMAC_Sig_Create(byte[] Data, string para_f) // функция для создания HMAC подписи
        {
            byte[] Sig = new byte[1];
            HMACSHA512 hmac = new HMACSHA512(File.ReadAllBytes(para_f)); // считываем параметры из файла и создаём на их основе объект класса HMACSHA512 (HMAC на основе SHA512)
            Sig = hmac.ComputeHash(Data); // создаём подпись (подписью является хэш)

            return Sig;
        }

        public bool HMAC_Sig_Ver(byte[] Data, byte[] Signature, string para_f) // функция проверки HMAC подписи
        {
            bool ver = true;
            HMACSHA512 hmac = new HMACSHA512(File.ReadAllBytes(para_f)); // создаём объект класса на основе параметров из файла
            byte[] ver_sig = hmac.ComputeHash(Data); // создаём подпись (хэш)
            for (int i = 0; i < ver_sig.Length; i++) // сравниваем хэши (должны быть равны)
                if (Signature[i] != ver_sig[i])
                    ver = false;

            return ver;
        }
    }
}
