﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace IS_lab3
{
    public partial class Hash : Form
    {
        public Hash()
        {
            InitializeComponent();
            comboBox1.Items.Add("SHA512");
            comboBox1.Items.Add("RIPEMD160");
            comboBox1.SelectedIndex = 0;
        }

        byte[] b_mess = new byte[1]; // сообщение в байтах
        string[] mess = new string[1]; // сообщение в строках
        string alg_flag = ""; // название алгоритма
        byte[] hash_arr = new byte[1]; // хэш

        private void Button3_Click(object sender, EventArgs e)
        {
            File_f F = new File_f();
            textBox2.Clear();
            string file_name = textBox1.Text;
            if (file_name == "") // проверка на ввод имени файла
                MessageBox.Show("Enter file name.");
            else
            {
                bool fl = File.Exists(file_name); // проверка на существование файла
                if (fl)
                {
                    b_mess = File.ReadAllBytes(file_name);
                    mess = F.Read(file_name);
                    string ms = "";
                    for (int i = 0; i < mess.Length; i++)
                        ms += mess[i];
                    textBox2.Text = ms;
                }
                else
                    MessageBox.Show("File don't exist.");
            }
        }

        private void Button1_Click(object sender, EventArgs e) // создаём хэш
        {
            textBox3.Clear();
            string file_sha = "SHA512.bin";
            string file_rip = "RIPEMD160.bin";
            Hash_alg hash = new Hash_alg();
            alg_flag = comboBox1.SelectedItem.ToString();
            if (alg_flag == "SHA512")
            {
                hash_arr = hash.SHA_512(b_mess);
                File.WriteAllBytes(file_sha, hash_arr);
            }
            if (alg_flag == "RIPEMD160")
            {
                hash_arr = hash.RIPEMD_160(b_mess);
                File.WriteAllBytes(file_rip, hash_arr);
            }

            for (int i = 0; i < hash_arr.Length; i++)
                textBox3.Text += hash_arr[i].ToString("x") + " ";

        }
    }
}
