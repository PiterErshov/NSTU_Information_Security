﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Security.Cryptography;

namespace IS_lab3
{
    class Asym_alg
    {
        public RSAParameters RSA_KEY_GEN() // генератор ключей для RSA алкоритма
        {
            RSACryptoServiceProvider RSA_key = new RSACryptoServiceProvider();
            return RSA_key.ExportParameters(true);
        }

        public byte[] RSA_Encrypt(byte[] data, RSAParameters RSA_key) // шифратор сообщения
        {
            RSACryptoServiceProvider RSA = new RSACryptoServiceProvider();
            byte[] res = new byte[1];

            RSA.ImportParameters(RSA_key); // получаем ключи

            res = RSA.Encrypt(data, true); // шифруем сообщение
            return res;
        }

        public byte[] RSA_Decrypt(byte[] data, RSAParameters RSA_key) // дешифратор сообщения
        {
            RSACryptoServiceProvider RSA = new RSACryptoServiceProvider();
            byte[] res = new byte[1];

            RSA.ImportParameters(RSA_key); // получаем ключ

            res = RSA.Decrypt(data, true); // дешифруем сообщение
            return res;
        }
    }
}
