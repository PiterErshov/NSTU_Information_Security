﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;

namespace IS_lab3
{
    public partial class Asym : Form
    {
        public Asym()
        {
            InitializeComponent();
        }

        RSAParameters RSA_key = new RSAParameters();
        byte[] b_mess = new byte[1]; // сообщение в байтах
        string[] mess = new string[1]; // сообщение в строках
        byte[] enc = new byte[1]; // шифротекст

        private void button3_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
            File_f F = new File_f();
            string file_name = textBox1.Text;
            if (file_name == "") // проверка на ввод имени файла
                MessageBox.Show("Enter file name.");
            else
            {
                bool fl = File.Exists(file_name); // проверка на существование файла
                if (fl)
                {
                    b_mess = File.ReadAllBytes(file_name);
                    mess = F.Read(file_name);
                    string ms = "";
                    for (int i = 0; i < mess.Length; i++)
                        ms += mess[i];
                    textBox2.Text = ms;
                }
                else
                    MessageBox.Show("File don't exist.");
            }
            
        }

        private void Button1_Click(object sender, EventArgs e) // шифруем сообщение
        {
            textBox3.Clear();
            Asym_alg AG = new Asym_alg();
            RSA_key = AG.RSA_KEY_GEN();
            enc = AG.RSA_Encrypt(b_mess, RSA_key);
            for (int i = 0; i < enc.Length; i++)
                textBox3.Text += enc[i].ToString("x") + " ";                      
        }

        private void Button2_Click(object sender, EventArgs e) // дешифруем сообщение
        {
            textBox4.Clear();
            Asym_alg AG = new Asym_alg();
            byte[] dec = AG.RSA_Decrypt(enc, RSA_key);
            string dec_res = Encoding.UTF8.GetString(dec, 0, dec.Length);
            textBox4.Text = dec_res;
        }
    }
}
