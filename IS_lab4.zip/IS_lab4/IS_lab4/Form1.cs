﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace IS_lab4
{
    public partial class Form1 : Form
    {
        public Form1()
        {            
            InitializeComponent();
        }
        string Log = "";
        private void Form1_Load(object sender, EventArgs e)
        {
            textBox2.PasswordChar = '*';
        }
        public string A_level_name(int i)
        {
            string s = "";
            if (i == 0)
                s = "гость";
            if (i == 1)
                s = "пользователь";
            if (i == 2)
                s = "администратор";

            return s;
        }
        private void Button1_Click_1(object sender, EventArgs e)
        {
            Log = textBox1.Text;
            if (Log == "")
                MessageBox.Show("Введите логин.");
            else
            {
                if (textBox2.Text == "")
                    MessageBox.Show("Введите пароль.");
                else
                {                    
                    if (DB_operation.Authentication(Log, textBox2.Text))
                    {
                        label3.Text = "Добро пожаловать " + A_level_name(Convert.ToInt32(Work_sess.Access)) + " " + Log;
                        Form2 examp = new Form2();
                        examp.Show();
                        Param.F1 = this;
                        Visible = false;
                    }
                    else
                    {
                        label3.Text = "Доступ запрещён.";
                        label4.Text = "Не верный логин или пароль.";
                    }
                }
            }
            
        }
    }
}
