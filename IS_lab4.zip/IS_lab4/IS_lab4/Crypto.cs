﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Security.Cryptography;
using System.Collections;

namespace IS_lab4
{
    class Crypto
    {
        public byte[] SHA_512(byte[] data) // генератор хэша на основе SHA512
        {
            byte[] res = new byte[1];

            SHA512 SHA = new SHA512Managed();

            res = SHA.ComputeHash(data);
            return res;
        }        
    }
}
