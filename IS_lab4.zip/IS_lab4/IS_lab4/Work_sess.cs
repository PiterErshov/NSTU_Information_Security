﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IS_lab4
{
    public static class Work_sess
    {        
        public static string login; //логин
        public static string name; //имя
        public static string s_name; //фамилия
        public static string pos; //должность
        public static Param.Access_level Access; //уровень доступа
    }
}
