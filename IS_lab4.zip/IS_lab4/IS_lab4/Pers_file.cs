﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace IS_lab4
{
    public partial class Form2 : Form
    {

        DataSet ds = new DataSet(); 
        DataTable dt = new DataTable();
        public Form2()
        {            
            InitializeComponent();
        }

        private void Form2_MouseDown(object sender, MouseEventArgs e) // событие для перемещения формы
        {
            base.Capture = false;
            Message m = Message.Create(base.Handle, 0xa1, new IntPtr(2), IntPtr.Zero);
            this.WndProc(ref m);
        }
        private void Form2_Load(object sender, EventArgs e) 
        {
            label1.Text = "Здравствуйте, " + Work_sess.login;
            button3.Visible = false; // блокировка кнопки обновления базы данных для гостя и пользователя            
        }

        private void Button1_Click(object sender, EventArgs e) // получение базы данных 
        {            
            var db_op = DB_operation.show_db();
            ds.Reset();
            db_op.Fill(ds);
            dt = ds.Tables[0];
            dataGridView1.DataSource = dt; // вывод таблицы

            switch (Work_sess.Access)
            {
                case Param.Access_level.l_2:
                    button3.Visible = true; // активация кнопки для обновления БД для администратора
                    break;
            }
        }

        private void Button3_Click(object sender, EventArgs e) // обновление базы данных
        {
            NpgsqlDataAdapter db_op;
            
            var con = new NpgsqlConnection(Param.DB_CONN_PARAMETERS);
            con.Open();

            db_op = new NpgsqlDataAdapter(Param.DB_USR_L1_2, con);
            
            NpgsqlCommandBuilder cmd = new NpgsqlCommandBuilder(db_op);
            db_op.UpdateCommand = cmd.GetUpdateCommand();
            db_op.Update((DataTable)dataGridView1.DataSource); // выполняем обновление БД

            con.Close();
        }

        private void ЛичныеДанныеToolStripMenuItem_Click(object sender, EventArgs e) // вывод личных данных
        {
            string a_l = "";
            switch (Work_sess.Access)
            {
                case Param.Access_level.l_0:
                    a_l = "чтение только своих персональных данных.";
                    break;
                case Param.Access_level.l_1:
                    a_l = "чтение персональных данных всех пользователей.";
                    break;
                case Param.Access_level.l_2:
                    a_l = "чтение и модификация персональных данных всех пользователей.";
                    break;
            }
            DB_operation.Pesonal_data();
            MessageBox.Show("Имя: " + Work_sess.name + "\n" +
                            "Фамилия: " + Work_sess.s_name + "\n" +
                            "Должность: " + Work_sess.pos + "\n" +
                            "Права доступа: " + a_l);
        }

        private void ВыходToolStripMenuItem_Click(object sender, EventArgs e) // выход из программы
        {
            Work_sess.login = "";
            Param.F1.Visible = true;
            Close();
        }
        private void ОПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Приложение 'Терминал Базы Данных'\n" +
                            "Разработано в рамках образовательного курса:\n" +
                            "Информационная Безопасность\n" +
                            "Разработчики: Ершов Пётр, Мамонова Елизавета, Цыденов Зана-Базар");
        }
        private void menuStrip1_MouseDown(object sender, MouseEventArgs e)
        {
            base.Capture = false;
            Message m = Message.Create(base.Handle, 0xa1, new IntPtr(2), IntPtr.Zero);
            this.WndProc(ref m);
        }
        private void Button2_Click(object sender, EventArgs e)
        {
            Work_sess.login = "";
            Param.F1.Visible = true;
            Close();
        }               
    }
}
