﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Collections;


namespace IS_lab1
{
    class Cripto
    {
        int bl = 32;  // длина слова в битах 
        int bt = 8;  // длина бита
        int N = 10;  // количество шестнадцатиричных слов в алгоритме
        int Mlen = 512; // длина одного блока в сообщении
        int oper = 80; // число операций в обработке одного 512-битного облока сообщения

         // Массив номеров сообщений 32-битных слов
        int[] R1 = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11,
                                12, 13, 14, 15, 7, 4, 13, 1, 10, 6,
                                15, 3, 12, 0, 9, 5, 2, 14, 11, 8, 3,
                                10, 14, 4, 9, 15, 8, 1, 2, 7, 0, 6, 13,
                                11, 5, 12, 1, 9, 11, 10, 0, 8, 12, 4,
                                13, 3, 7, 15, 14, 5, 6, 2, 4, 0, 5, 9,
                                7, 12, 2, 10, 14, 1, 3, 8, 11, 6, 15, 13 };
         // Массив номеров сообщений 32-битных слов
        int[] R2 = new int[] { 5, 14, 7, 0, 9, 2, 11, 4, 13, 6, 15, 8,
                                1, 10, 3, 12, 6, 11, 3, 7, 0, 13, 5,
                                10, 14, 15, 8, 12, 4, 9, 1, 2, 15, 5,
                                1, 3, 7, 14, 6, 9, 11, 8, 12, 2, 10, 0,
                                4, 13, 8, 6, 4, 1, 3, 11, 15, 0, 5, 12,
                                2, 13, 9, 7, 10, 14, 12, 15, 10, 4, 1,
                                5, 8, 7, 6, 2, 13, 14, 0, 3, 9, 11 };

         // Массив битовых сдвигов
        int[] S1 = new int[] { 11, 14, 15, 12, 5, 8, 7, 9, 11, 13, 14, 15,
                                 6, 7, 9, 8, 7, 6, 8, 13, 11, 9, 7, 15, 7, 12,
                                15, 9, 11, 7, 13, 12, 11, 13, 6, 7, 14, 9, 13,
                                15, 14, 8, 13, 6, 5, 12, 7, 5, 11, 12, 14, 15,
                                14, 15, 9, 8, 9, 14, 5, 6, 8, 6, 5, 12, 9, 15,
                                5, 11, 6, 8, 13, 12, 5, 12, 13, 14, 11, 8, 5, 6 };
         // Массив битовых сдвигов
        int[] S2 = new int[] { 8, 9, 9, 11, 13, 15, 15, 5, 7, 7, 8, 11, 14,
                                14, 12, 6, 9, 13, 15, 7, 12, 8, 9, 11, 7, 7,
                                12, 7, 6, 15, 13, 11, 9, 7, 15, 11, 8, 6, 6,
                                14, 12, 13, 5, 14, 13, 13, 7, 5, 15, 5, 8, 11,
                                14, 14, 6, 14, 6, 9, 12, 9, 12, 5, 15, 8, 8, 5,
                                12, 9, 12, 5, 14, 6, 8, 13, 6, 5, 15, 13, 11, 11 };

        uint[] k_const1 = new uint[5] { 0x00000000, 0x5a827999, 0x6ed9eba1, 0x8f1bbcdc, 0xa953fd4e }; // массив для фукнции K1
        uint[] k_const2 = new uint[5] { 0x50a28be6, 0x5c4dd124, 0x6d703ef3, 0x7a6d76e9, 0x00000000 }; // массив для фукнции K2
        uint[] h = new uint[10] { 0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476, 0xc3d2e1f0,
                                  0x76543210, 0xfedcba98, 0x89abcdef, 0x01234567, 0x3c2d1e0f }; // массив начальных для выходного массива 4-битовых хэшей
        public void Write(string fileName, string[] outw)  // Запись входной строки и ключа в файл
        {
            using (StreamWriter sw = new StreamWriter(fileName))
            {
                foreach (string str in outw)
                    sw.WriteLine(str);
            }
        }
        public string[] Read(string fileName)  // чтение строки
        {
            List<string> list = new List<string>();
            using (StreamReader reader = new StreamReader(fileName, Encoding.GetEncoding(1251)))
            {
                while (!reader.EndOfStream)
                {
                    string str = reader.ReadLine();
                    list.Add(str);
                }
            }
            return list.ToArray();
        }

        public byte[] in_mass(byte[] x, byte[] y, byte j) // поместить массив y в массив x начиная с j-позиции
        {
            for (int i = 0; i < y.Length; i++)
                x[j + i] = y[i];
            return x;
        }
                
        public uint shift(uint x, int S) // циклический битовый сдвиг
        {
            return (x << S) ^ (x >> (bl - S)); // проводим операцию XOR между смещённым влево на S бит числом и числом, смещённым на 32 - S бит
        }
        
        public uint f(int j, uint x, uint y, uint z) //  битовая функция f
        {
            uint f_out = 0;

            if (0 <= j && j <= 15)
                f_out = x ^ y ^ z;
            if (16 <= j && j <= 31)
                f_out = (x & y) | (~x & z);
            if (32 <= j && j <= 47)
                f_out = (x | ~y) ^ z;
            if (48 <= j && j <= 63)
                f_out = (x ^ z) | (y & ~z);
            if (64 <= j && j <= 79)
                f_out = x ^ (y | ~z);

            return f_out;
        }

        public uint K_f(int j, int f) //  функции K1 и K2
        {
            uint f_out = 0;

            if (f == 0)
                f_out = k_const1[j / 16];
            else
                f_out = k_const2[j / 16];

            return f_out;
        }

        public byte[] take_mas(byte[] X, int j, int l) // получение части массива X длиной l спозиции j
        {
            byte[] f_out = new byte[l];

            for (int i = 0; i < l; i++)
                f_out[i] = X[j + i];
            return f_out;
        }

        public double btod(int[] X, int f) // перевод двоичного числа в десятичное (f - параметр разряда числа)
        {
            double res = 0;
            for (int i = 0; i < f; i++)
            {
                res += X[i] * Math.Pow(2, 7 - i);
            }
            return res;
        }

        public bool sort(byte[] X) // проверка упорядоченности массива X
        {
            int i = 0;
            while (i < X.Length - 1)
            {
                if (X[i] > X[i + 1])
                    return false;
                i ++;
            }
            return true;
        }

        
        public byte[] l_end(byte[] X) // перевод сообщения к порядку little-endian (сортировка от)
        {
            byte[] f_out = new byte[X.Length]; // выходной массив
            byte buf = 0 ; // буфер

            f_out = in_mass(f_out, X, 0); // перенос входного массива в выходной массив

            while (!sort(f_out))
            {
                int i = 0;
                while (i < f_out.Length - 1)
                {
                    if (f_out[i] > f_out[i + 1]) // сравнение соседних 32-битных слов
                    {
                        buf = f_out[i];
                        f_out[i] = f_out[i + 1];
                        f_out[i + 1] = buf;
                    }
                    i ++;
                }
            }
            return f_out;
        }


        static int add2pyramid(byte[] arr, int i, int N)
        {
            int imax;
            byte buf;
            if ((2 * i + 2) < N)
            {
                if (arr[2 * i + 1] < arr[2 * i + 2]) imax = 2 * i + 2;
                else imax = 2 * i + 1;
            }
            else imax = 2 * i + 1;
            if (imax >= N) return i;
            if (arr[i] < arr[imax])
            {
                buf = arr[i];
                arr[i] = arr[imax];
                arr[imax] = buf;
                if (imax < N / 2) i = imax;
            }
            return i;
        }
        public static void sorting(byte[] arr, int len)
        {
            //step 1: building the pyramid
            for (int i = len / 2 - 1; i >= 0; --i)
            {
                long prev_i = i;
                i = add2pyramid(arr, i, len);
                if (prev_i != i) ++i;
            }

            //step 2: sorting
            byte buf;
            for (int k = len - 1; k > 0; --k)
            {
                buf = arr[0];
                arr[0] = arr[k];
                arr[k] = buf;
                int i = 0, prev_i = -1;
                while (i != prev_i)
                {
                    prev_i = i;
                    i = add2pyramid(arr, i, k);
                }
            }
        }

        public byte[] mes_add(byte[] X) // добавление недостающих бит в сообщение 
        {
            byte[] a_mes = new byte[1];
            byte[] in_add = new byte[1];
            int b_len = 8 * X.Length;
                        
            for (int i = 0; i < X.Length; i++)
            {
                in_add[i] = X[i];
                Array.Resize(ref in_add, in_add.Length + 1);
            }
            Array.Resize(ref in_add, in_add.Length - 1);

            int k = (8 * in_add.Length);
            int j = 0;
            a_mes[0] = 0b10000000;
            j++;
            k += 8;
            while (k % Mlen != 448)
            {
                Array.Resize(ref a_mes, a_mes.Length + 1);
                a_mes[j] += 0b00000000;
                j++;
                k += 8;
            }
            in_add = in_add.Concat(a_mes).ToArray();
            //in_add = l_end(in_add);
            sorting(in_add, in_add.Length);

            byte[] end = BitConverter.GetBytes((ulong)b_len);

            in_add = in_add.Concat(take_mas(end, 4, 4)).ToArray();
            in_add = in_add.Concat(take_mas(end, 0, 4)).ToArray();

            return in_add;
        }

        
        public uint[] Pars(byte[] X) // парсим сообщение из массива int чисел, в массив uint чисел
        {
            uint[] w = new uint[Mlen / bl]; // выделяем массив на 16 32-разрядных числа
            int i = 0;
            int k = 0;
            while (i < X.Length)
            {                
                w[k] = BitConverter.ToUInt32(X, i);
                k++;
                i += bt / 2;
            }
            return w;
        }
        ///*
        public uint[] encoder(byte[] Mess) // функция шифрования (на вход передаём сообщение в строке)
        {
            byte[] X = mes_add(Mess);
            uint[] H = new uint[N]; // массив результирующих хэшей
            uint[] buf1 = new uint[N / 2]; // массив хэшей A1, B1, C1, D1, E1 
            uint[] buf2 = new uint[N / 2]; // массив хэшей A2, B2, C2, D2, E2 
            uint[] w = new uint[Mlen / bl]; // массив с одним 512-битным блоком, разбитый на 16 32-битных слова
            uint T = 0;
            int i = 0;
            for (int k = 0; k < h.Length; k++) // заносим начальные значения хэшей
                H[k] = h[k];
            
            while (i < X.Length) // цикл по всему сообщению
            {
                w = Pars(take_mas(X, i, Mlen / bt)); // получаем 512-битный блок
                for (int k = 0; k < N / 2; k++) // заносим в массивы хэшей начальные значения
                {
                    buf1[k] = H[k];
                    buf2[k] = H[k + N / 2];
                }

                for(int j = 0; j < oper; j++) // основной цикл шифрования
                {
                    T = shift((buf1[0] ^ f(j, buf1[1], buf1[2], buf1[3]) 
                        ^ w[R1[j]] ^ K_f(j, 0)), S1[j]) ^ buf1[4];
                    buf1[0] = buf1[4];
                    buf1[4] = buf1[3];
                    buf1[3] = shift(buf1[2], 10);
                    buf1[2] = buf1[1];
                    buf1[1] = T;
                    T = shift((buf2[0] ^ f(oper - 1 - j, buf2[1], buf2[2], buf2[3])
                        ^ w[R2[j]] ^ K_f(j, 1)), S2[j]) ^ buf2[4];
                    buf2[0] = buf2[4];
                    buf2[4] = buf2[3];
                    buf2[3] = shift(buf2[2], 10);
                    buf2[2] = buf2[1];
                    buf2[1] = T;

                    if(j == 15)
                    {
                        T = buf1[1];
                        buf1[1] = buf2[1];
                        buf2[1] = T;
                    }
                    if (j == 31)
                    {
                        T = buf1[3];
                        buf1[3] = buf2[3];
                        buf2[3] = T;
                    }
                    if (j == 47)
                    {
                        T = buf1[0];
                        buf1[0] = buf2[0];
                        buf2[0] = T;
                    }
                    if (j == 63)
                    {
                        T = buf1[2];
                        buf1[2] = buf2[2];
                        buf2[2] = T;
                    }
                    if (j == 79)
                    {
                        T = buf1[4];
                        buf1[4] = buf2[4];
                        buf2[4] = T;
                    }
                }
                for(int k = 0; k < N / 2; k++) // получаем промежуточные значения хэшей
                {
                    H[k] = H[k] ^ buf1[k];
                    H[k + N / 2] = H[k + N / 2] ^ buf2[k];
                }
                i += (Mlen / bt); // смещаемся в сообщении на следующие 512 бит
            }

            return H;
        }

        public int bit_compar(uint[] X, uint[] Y) // сравнение двух хэш-функций на отличающиеся биты
        {
            int ch = 0; // число изменившихся бит

            for (int i = 0; i < X.Length; i++)
            {
                // конертируем массив uint сначала в массив байтов, затем в массив битов
                byte[] bufX = BitConverter.GetBytes(X[i]);
                byte[] bufY = BitConverter.GetBytes(Y[i]);
                BitArray X1 = new BitArray(bufX);
                BitArray Y1 = new BitArray(bufY);

                for (int j = 0; j < X1.Length; j++)
                    if (X1[j] != Y1[j])
                        ch++;
            }
            return ch;
        }
       
        public uint[] bit_corrector(uint[] X, int y) // инвертирует бит под номером y
        {
            uint buf = 1;
            X[y / 32] ^= (buf << (bl - 1 - y % bl));
            return X;
        }

        public int[] avalanche_eff(byte[] Mess, uint[] H_f, int n_bit) // функция исследования лавинного эффекта при изменении бита под номером n_bit)
        {
            byte[] X = mes_add(Mess);
            uint[] H_test = new uint[N]; // массив первичных хэшей для исследования
            uint[] buf1 = new uint[N / 2]; // массив хэшей A1, B1, C1, D1, E1 
            uint[] buf2 = new uint[N / 2]; // массив хэшей A2, B2, C2, D2, E2 
            uint[] w = new uint[Mlen / bl]; // массив с одним 512-битным блоком, разбитый на 16 32-битных слова
            int[] stat = new int[oper];
            uint T = 0; // 

            w = Pars(take_mas(X, 0, Mlen / bt)); // получаем 512-битный блок
                      
            for (int k = 0; k < h.Length; k++) // заносим начальные значения хэшей
                H_test[k] = h[k];

            for (int k = 0; k < N / 2; k++) // заносим в массивы хэшей начальные значения
            {
                buf1[k] = H_test[k];
                buf2[k] = H_test[k + N / 2];
            }

            w = bit_corrector(w, n_bit); // изменяем бит n_bit в сообщении

            for (int j = 0; j < oper; j++) // основной цикл шифрования
            {
                T = shift((buf1[0] ^ f(j, buf1[1], buf1[2], buf1[3])
                    ^ w[R1[j]] ^ K_f(j, 0)), S1[j]) ^ buf1[4];
                buf1[0] = buf1[4];
                buf1[4] = buf1[3];
                buf1[3] = shift(buf1[2], 10);
                buf1[2] = buf1[1];
                buf1[1] = T;
                T = shift((buf2[0] ^ f(oper - 1 - j, buf2[1], buf2[2], buf2[3])
                    ^ w[R2[j]] ^ K_f(j, 1)), S2[j]) ^ buf2[4];
                buf2[0] = buf2[4];
                buf2[4] = buf2[3];
                buf2[3] = shift(buf2[2], 10);
                buf2[2] = buf2[1];
                buf2[1] = T;

                if (j == 15)
                {
                    T = buf1[1];
                    buf1[1] = buf2[1];
                    buf2[1] = T;
                }
                if (j == 31)
                {
                    T = buf1[3];
                    buf1[3] = buf2[3];
                    buf2[3] = T;
                }
                if (j == 47)
                {
                    T = buf1[0];
                    buf1[0] = buf2[0];
                    buf2[0] = T;
                }
                if (j == 63)
                {
                    T = buf1[2];
                    buf1[2] = buf2[2];
                    buf2[2] = T;
                }
                if (j == 79)
                {
                    T = buf1[4];
                    buf1[4] = buf2[4];
                    buf2[4] = T;
                }

                for (int k = 0; k < N / 2; k++) // получаем промежуточные значения хэшей
                {
                    H_test[k] ^= buf1[k];
                    H_test[k + N / 2] ^= buf2[k];
                }
                stat[j] = bit_compar(H_f, H_test); // сравниваем полученную хэш-функцию с изначальной
            }
                     
            return stat;
        }
        //*/
    }
}
