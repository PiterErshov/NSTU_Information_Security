﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.IO;
using System.Windows.Forms.DataVisualization.Charting;

namespace IS_lab1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Cripto Cr = new Cripto(); // инициализируем основной класс
        uint[] H = new uint[1]; // массив хэш-функции
        string[] m = new string[1]; // промежуточный массив сообщения (нужен для чтения из файла)
        byte[] mess = new byte[1];
        private void Button1_Click(object sender, EventArgs e)
        {            
            string file_name = textBox3.Text; // имя файла
            string ms = "";
            if (file_name == "") // проверка на ввод имени файла
                MessageBox.Show("Enter file name.");
            else
            {
                bool fl = File.Exists(file_name); // проверка на существование файла
                if (fl)
                {
                    richTextBox1.Clear();
                    m = Cr.Read(file_name);
                    for (int i = 0; i < m.Length; i++)
                        ms += m[i];
                    for (int i = 0; i < m.Length; i++)
                        richTextBox1.Text = m[i];
                    if (m.Length == 0)
                        ms = "";
                    mess = File.ReadAllBytes(file_name);
                    textBox1.Clear();
                    H = Cr.encoder(mess); // функция хэширования
                    for (int i = 0; i < H.Length; i++)
                        textBox1.Text += (H[i]).ToString("x") + " | ";
                    richTextBox1.Text = ms;
                }
                else
                    MessageBox.Show("File don't exist.");

            }            
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            string m = textBox2.Text; // номер бита, который нужно изменить
            
            if (m == "")
                MessageBox.Show("Enter the bit number.");
            else
            {
                int n_bit = Convert.ToInt32(m); // номер изменяемого бита в int формате
                int[] stat = Cr.avalanche_eff(mess, H, n_bit); // получаем статистику изменения хэш-функции
                chart1.Series.Clear();
                // Add series.
                for (int i = 0; i < stat.Length; i++)
                {
                    // Add series.
                    chart1.Series.Add(Convert.ToString(i));
                    chart1.Series[0].Points.AddXY(i + 1, stat[i]);

                }
                chart1.Series[0].ChartType = SeriesChartType.Line;
                chart1.Legends.Clear();
            }
        }
    }
}
